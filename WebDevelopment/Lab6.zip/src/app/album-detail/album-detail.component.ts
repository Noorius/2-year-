import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Album, albums } from '../albums';

import { AlbumsService } from '../albums.service';

@Component({
  selector: 'app-album-detail',
  templateUrl: './album-detail.component.html',
  styleUrls: ['./album-detail.component.css']
})
export class AlbumDetailComponent implements OnInit {
  album: Album | undefined;
  main_title: string | undefined;

  albums = albums//

  constructor(
    private route: ActivatedRoute,
    private albumsService: AlbumsService //
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.paramMap;
    const productIdFromRoute = Number(routeParams.get('albumId'));

    this.album = albums.find(album => album.id == productIdFromRoute);
    this.main_title = this.album.title;
  }

  save(newTitle: any){
    if(newTitle){
      this.main_title = newTitle;
      albums[albums.indexOf(this.album,0)].title = newTitle;
    }

  }

}