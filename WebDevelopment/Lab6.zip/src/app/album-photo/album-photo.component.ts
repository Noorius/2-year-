import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { photos, Photo } from '../albums';

@Component({
  selector: 'app-album-photo',
  templateUrl: './album-photo.component.html',
  styleUrls: ['./album-photo.component.css']
})
export class AlbumPhotoComponent implements OnInit {
  photos = photos;
  an_id: number | undefined;

  constructor(
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.paramMap;
    const productIdFromRoute = Number(routeParams.get('albumId'));
    this.an_id = productIdFromRoute;
  }

}