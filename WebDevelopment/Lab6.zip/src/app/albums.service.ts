import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Album, Photo } from './albums';

@Injectable({
  providedIn: 'root',
})



export class AlbumsService {
  fetched_albums: Album[] = [];
  fetched_photos: Photo[] = [];

  constructor(
    private http: HttpClient
  ) { }

  getAlbums(){
    let obser = this.http.get<{
      userId : number;
      id: number;
      title: string;}[]>
    ('/assets/albums.json');
    
    obser.subscribe({
      next:(x:any) => {
        for(let y of x){
          let al : Album = JSON.parse(JSON.stringify(y));
          this.fetched_albums.push(al);
        }
      }
    });

    return this.fetched_albums;
  }

  getPhotos(){
    let obser = this.http.get<{
      albumId: number;
      id: number;
      title: string;
      url: string;
      thumbnailUrl: string;}[]>
    ('/assets/photos.json');
    
    obser.subscribe({
      next:(x:any) => {
        for(let y of x){
          let al : Photo = JSON.parse(JSON.stringify(y));
          this.fetched_photos.push(al);
        }
      }
    });

    return this.fetched_photos;
  }
}