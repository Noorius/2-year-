import { NONE_TYPE } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit, Input } from '@angular/core';
import { Album, albums } from '../albums';
import { AlbumsService } from '../albums.service';


@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css']
})
export class AlbumsComponent implements OnInit {

  albums = albums//this.albumsService.fetched_albums;//this.albumsService.getAlbums();

  constructor(private albumsService: AlbumsService) { 
  
  }

  ngOnInit() {
    this.albums = albums;
  }

  delete(al: any){
    for(let i = 0; i<this.albums.length; i++){
      if(this.albums[i]==al){
        this.albums.splice(i,1);
      }
    }
  }
  
  edit(link: any){
    link.contentEditable = true;
    link.style = "color: CurrentColor; opacity: 0.5; pointer-events: none;"
  }
  
  change(link: any, al: any){
    al.title = link.innerText;

    link.contentEditable = false;
    link.style = "opacity: 1;"
    console.log(link.contentEditable);
    return false;
  }

  add(inp: any){
    if(inp.value!=""){
      inp.hidden = true;
      albums.push({userId: 0, id: albums.length+1, title: inp.value});
      inp.value="";
    }else{
      inp.hidden = false;
    }
    
  }

}